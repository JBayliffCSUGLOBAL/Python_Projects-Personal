# This program prints Hello, world!
name = "Jon"
print('Hello, world!')
print(name)

