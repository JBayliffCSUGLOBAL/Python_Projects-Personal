from numpy import random

x = random.rand()

print(x)