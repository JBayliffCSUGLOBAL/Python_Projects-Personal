# Keylogger_Code
# Project Name

One of the codes used in cybersecurity is a keylogger.  In this file you will see I created a keylogger code using python.  This is intended for training purposes only to showcase my skillset in creating a simple code to assist in job placement for career outlooks.
